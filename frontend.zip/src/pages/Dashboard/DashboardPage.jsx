import React from 'react'

export default function DashboardPage() {
  return (
    <div>DashboardPage</div>
  )
}
